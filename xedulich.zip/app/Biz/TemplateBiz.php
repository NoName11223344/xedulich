<?php

namespace App\Biz;

use App\Entity\Template;

class TemplateBiz
{
     public static function storeTemplate($param) {
         $template = new Template();
         // if exist title

         
    }
}
